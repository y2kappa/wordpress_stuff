<?php return array(

	# Hidden fields
	'settings_saved_once'                   => '0',
	# General
	'values_store_mod'                => 'theme_mod',

	'typography' => true,
	'typography_standard_fonts' => true,
	'typography_google_fonts' => true,
	'typography_group_google_fonts' => true,
	'disable_default_sections' => array(),
	'disable_customify_sections' => array(),
	'enable_reset_buttons' => false,
	'enable_editor_style' => true,
	'style_resources_location' => 'wp_head'
); # config
