window.fontPalettesVariations = {
    'light': {

    },
    'regular': {

    },
    'big': {

    }
};