<?php
//not used yet - moved them to a per gallery option

return array(
	'type'    => 'postbox',
	'label'   => 'Tools',
	'options' => array(
		'reset_theme_mod' =>  array(
			'name'    => 'reset_theme_mod',
			'label'   => __( 'Reset', 'customify' ),
			'type'           => 'reset_theme_mod',
		)
	)
); # config